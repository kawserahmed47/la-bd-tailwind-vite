<?php

namespace App\Http\Controllers;

use App\Models\BasicSettings\RoleMenuPermission;
use Illuminate\Http\Request;

class RoleMenuPermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(RoleMenuPermission $roleMenuPermission)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(RoleMenuPermission $roleMenuPermission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, RoleMenuPermission $roleMenuPermission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(RoleMenuPermission $roleMenuPermission)
    {
        //
    }
}
