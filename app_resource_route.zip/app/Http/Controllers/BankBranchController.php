<?php

namespace App\Http\Controllers;

use App\Models\BasicSettings\BankBranch;
use Illuminate\Http\Request;

class BankBranchController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(BankBranch $bankBranch)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(BankBranch $bankBranch)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, BankBranch $bankBranch)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(BankBranch $bankBranch)
    {
        //
    }
}
