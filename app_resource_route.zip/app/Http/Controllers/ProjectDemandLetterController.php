<?php

namespace App\Http\Controllers;

use App\Models\ProjectManagement\ProjectDemandLetter;
use Illuminate\Http\Request;

class ProjectDemandLetterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ProjectDemandLetter $projectDemandLetter)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ProjectDemandLetter $projectDemandLetter)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ProjectDemandLetter $projectDemandLetter)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ProjectDemandLetter $projectDemandLetter)
    {
        //
    }
}
