@extends('frontend.master', ['title' => 'Home'])

@section('content')
    <h1>Homepage</h1>
@endsection